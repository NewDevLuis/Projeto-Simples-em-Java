
public enum string {

}
